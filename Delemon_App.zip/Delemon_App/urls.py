from django.urls import path
from .import views
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [
    path('base', views.base, name='base'),
    path('', views.home, name='home'),
    path('privacy', views.privacy, name='privacy'),
    path('terms', views.terms, name='terms'),
    path('contact', views.contact, name='contact'),
    path('about', views.about, name='about'),
    path('digital', views.digital, name='digital'),
    path('web', views.web, name='web'),
    path('services', views.services, name='services'),
    path('mobile', views.mobile, name='mobile'),
    path('ecommerce', views.ecommerce, name='ecommerce'),
    path('uiux', views.uiux, name='uiux'),
    path('animation', views.animation, name='animation'),
] 

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
