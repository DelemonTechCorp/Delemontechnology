from django.shortcuts import render

# Create your views here.

def base(request):
    return render(request, 'base.html')

def home(request):
    return render(request, 'main/home.html')

def about(request):
    return render(request, 'main/about.html')

def privacy(request):
    return render(request, 'main/privacy.html')

def terms(request):
    return render(request, 'main/terms.html')

def contact(request):
    return render(request, 'main/contact.html')

def services(request):
    return render(request, 'main/services.html')

def digital(request):
    return render(request, 'main/digital.html')

def web(request):
    return render(request, 'main/web.html')

def mobile(request):
    return render(request, 'main/mobile.html')

def ecommerce(request):
    return render(request, 'main/ecommerce.html')

def uiux(request):
    return render(request, 'main/uiux.html')

def animation(request):
    return render(request, 'main/animation.html')